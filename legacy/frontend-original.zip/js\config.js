window.APP_CONFIG={
  API_BASE_URL:'http://localhost:5000/api',
  GROCERY:['Food Products','Beverages','FMCG','Personal Care','Household Products'],
  MEDICAL:['Tablets','Capsules','Syrups','Injections','First Aid','Medical Supplies']
};