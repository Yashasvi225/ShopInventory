const tbody = document.getElementById('body');
const generateBtn = document.getElementById('generate');
const refreshBtn = document.getElementById('refresh');
const statusText = document.getElementById('aiStatus');
const generatedText = document.getElementById('generatedAt');

function urgencyClass(value) {
  if (value === 'CRITICAL') return 'out';
  if (value === 'HIGH' || value === 'MEDIUM') return 'warn';
  return 'ok';
}

function renderRows(rows) {
  if (!rows.length) {
    tbody.innerHTML = '<tr><td colspan="6" class="empty-cell">No reorder recommendations right now. Your current stock levels do not require action.</td></tr>';
    return;
  }
  tbody.innerHTML = rows.map(row => `
    <tr>
      <td><strong>${escapeHtml(row.productName)}</strong></td>
      <td>${Number(row.currentStock) || 0}</td>
      <td>${Number(row.averageDailySales || 0).toFixed(2)}</td>
      <td><strong>${Number(row.suggestedReorderQuantity) || 0}</strong></td>
      <td><span class="badge ${urgencyClass(row.urgency)}">${escapeHtml(row.urgency)}</span></td>
      <td class="reason-cell">${escapeHtml(row.reason)}</td>
    </tr>`).join('');
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>'"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[ch]));
}

async function loadRecommendations(showToast = false) {
  App.setLoading(generateBtn, true, 'Analyzing...');
  if (refreshBtn) refreshBtn.disabled = true;
  statusText.textContent = 'Analyzing real inventory and sales data...';
  tbody.innerHTML = '<tr><td colspan="6" class="empty-cell">Loading recommendations...</td></tr>';
  try {
    const data = await App.api('/ai/reorder-suggestions');
    renderRows(data.suggestions || []);
    statusText.textContent = data.source === 'GEMINI'
      ? 'Generated with Gemini using your inventory and sales data.'
      : data.source === 'RULE_BASED'
        ? 'Gemini is unavailable, so safe rule-based recommendations are shown.'
        : 'Add products and sales data to generate recommendations.';
    generatedText.textContent = data.generatedAt ? `Last generated: ${new Date(data.generatedAt).toLocaleString('en-IN')}` : '';
    if (showToast) App.toast('Recommendations refreshed');
  } catch (error) {
    tbody.innerHTML = '<tr><td colspan="6" class="empty-cell">Recommendations could not be loaded. Please try again.</td></tr>';
    statusText.textContent = error.message || 'Unable to generate recommendations.';
    App.toast(statusText.textContent, 'error');
  } finally {
    App.setLoading(generateBtn, false);
    if (refreshBtn) refreshBtn.disabled = false;
  }
}

document.addEventListener('DOMContentLoaded', () => {
  generateBtn.addEventListener('click', () => loadRecommendations(true));
  refreshBtn?.addEventListener('click', () => loadRecommendations(true));
  tbody.innerHTML = '<tr><td colspan="6" class="empty-cell">Click Generate AI Recommendations to analyze your current inventory.</td></tr>';
});
